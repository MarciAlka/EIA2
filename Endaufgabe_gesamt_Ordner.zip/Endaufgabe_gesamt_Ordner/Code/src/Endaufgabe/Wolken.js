/*
    Name: Denise Marcella Alka
    Matrikel: 256690
    Datum: 06.02.2017
    Hiermit versichere ich, dass ich diesen
    Code selbst geschrieben habe. Er wurde
    nicht kopiert und auch nicht diktiert
 */
var End1;
(function (End1) {
    class Wolken extends End1.Objekt {
        constructor(_x, _y) {
            super(_x, _y);
            this.x = _x;
            this.y = _y;
        }
        move() {
            if (this.x > End1.scale * 800) {
                this.x = 0;
            }
            this.x += End1.scale * 10;
            this.y += 0;
        }
        draw() {
            End1.crc2.beginPath();
            End1.crc2.arc(this.x, this.y, 10 * End1.scale, 0, End1.scale * 2 * Math.PI); //10 radius
            End1.crc2.fillStyle = "#FFFFFF";
            End1.crc2.fill();
            //W1.2
            End1.crc2.beginPath();
            End1.crc2.arc(this.x + End1.scale * 10, this.y + End1.scale * 10, 10, 0, End1.scale * 2 * Math.PI);
            End1.crc2.fillStyle = "#FFFFFF";
            End1.crc2.fill();
            //W1.3
            End1.crc2.beginPath();
            End1.crc2.arc(this.x - End1.scale * 10, this.y + End1.scale * 10, 10 * End1.scale, 0, End1.scale * 2 * Math.PI); //10 radius
            End1.crc2.fillStyle = "#FFFFFF";
            End1.crc2.fill();
            //W1.4
            End1.crc2.beginPath();
            End1.crc2.arc(this.x, this.y + End1.scale * 8, 10 * End1.scale, 0, End1.scale * 2 * Math.PI);
            End1.crc2.fillStyle = "#FFFFFF";
            End1.crc2.fill();
        } //draw
    }
    End1.Wolken = Wolken; //class
})(End1 || (End1 = {})); //namespace
//# sourceMappingURL=Wolken.js.map