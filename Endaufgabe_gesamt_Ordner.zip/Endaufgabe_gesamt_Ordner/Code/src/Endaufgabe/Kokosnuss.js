/*
    Name: Denise Marcella Alka
    Matrikel: 256690
    Datum: 06.02.2017
    Hiermit versichere ich, dass ich diesen
    Code selbst geschrieben habe. Er wurde
    nicht kopiert und auch nicht diktiert
*/
var End1;
(function (End1) {
    let kokoId = 0;
    class Kokosnuss extends End1.Objekt {
        constructor(_x, _y) {
            super(_x, _y);
            this.x = _x;
            this.y = _y;
            this.kokoId = ++kokoId;
        }
        move() {
            if (this.y > 600 * End1.scale) {
                End1.deleteKokosnuss(this.kokoId);
            }
            //test
            this.y += 10; //Math.random();
        }
        draw() {
            End1.crc2.beginPath();
            End1.crc2.arc(this.x, this.y, End1.scale * 20, 0, 2 * Math.PI);
            End1.crc2.fillStyle = "#8B4513";
            End1.crc2.fill();
            /*HITZONE
            crc2.beginPath();
            crc2.fillStyle = "orange";
            crc2.moveTo(this.x-20, this.y+20);
            crc2.lineTo(this.x+20,this.y+20);
            //crc2.fillStyle = "orange";
            crc2.stroke();
            */
        }
    }
    End1.Kokosnuss = Kokosnuss;
})(End1 || (End1 = {}));
//# sourceMappingURL=Kokosnuss.js.map