/*
    Name: Denise Marcella Alka
    Matrikel: 256690
    Datum: 06.02.2017
    Hiermit versichere ich, dass ich diesen
    Code selbst geschrieben habe. Er wurde
    nicht kopiert und auch nicht diktiert
 */
var End1;
(function (End1) {
    class Krabbe extends End1.Objekt {
        constructor(_x, _y) {
            super(_x, _y);
            this.x = _x;
            this.y = _y;
            this.dx = _x;
            this.move();
        }
        move() {
            /*
            this.x += this.dx;
            
            if (this.x > 800) {
                this.x = 800;
            }

            if (this.x < 0) {
                this.x = 0;
            }
            */
            const speed = 10 * End1.scale;
            let movement = 0;
            if (this.x > this.dx && this.x - this.dx > speed)
                movement = -speed;
            else if (this.x < this.dx && this.dx - this.x > speed)
                movement = speed;
            this.x += movement;
            this.draw();
        }
        /*
        move_Krabbe_links(): void {
                this.dx =- 10;
        }

        move_Krabbe_rechts(): void {
            
                this.dx = + 10;
        }
        */
        move_Krabbe(targetX) {
            this.dx = targetX;
        }
        stop_Krabbe() {
            this.dx = this.x;
        }
        draw() {
            //Krabbe
            //void ctx.quadraticCurveTo(cpx, cpy, x, y);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x, this.y);
            End1.crc2.moveTo(this.x - 15 * End1.scale, this.y);
            /*
            crc2.quadraticCurveTo(5, 45, this.x-25, this.y+27);
            crc2.quadraticCurveTo(40, 70, this.x, this.y+22);
            crc2.quadraticCurveTo(60, 40, this.x-15, this.y);
            */
            End1.crc2.quadraticCurveTo(this.x - End1.scale * 45, this.y + End1.scale * 7, this.x - End1.scale * 25, this.y + End1.scale * 27);
            End1.crc2.quadraticCurveTo(this.x - End1.scale * 10, this.y + End1.scale * 32, this.x, this.y + End1.scale * 22);
            End1.crc2.quadraticCurveTo(this.x + End1.scale * 10, this.y + End1.scale * 2, this.x - End1.scale * 15, this.y);
            End1.crc2.stroke();
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Krabbenbein    
            //Bein 1 links
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 32, this.y + End1.scale * 2, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 37, this.y + End1.scale * 3, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillRect(this.x - End1.scale * 42, this.y + End1.scale * 4, End1.scale * 6, End1.scale * 6);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x - End1.scale * 40, this.y + End1.scale * 9); //untere
            End1.crc2.lineTo(this.x - End1.scale * 50, this.y + End1.scale * 12); //linke spitze
            End1.crc2.lineTo(this.x - End1.scale * 40, this.y + End1.scale * 4);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Bein 2 links
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 32, this.y + End1.scale * 9, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 37, this.y + End1.scale * 10, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillRect(this.x - End1.scale * 42, this.y + End1.scale * 11, End1.scale * 6, End1.scale * 6);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x - End1.scale * 40, this.y + End1.scale * 16);
            End1.crc2.lineTo(this.x - End1.scale * 50, this.y + End1.scale * 19);
            End1.crc2.lineTo(this.x - End1.scale * 40, this.y + End1.scale * 11);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Bein 3 links
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 32, this.y + End1.scale * 16, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 37, this.y + End1.scale * 17, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillRect(this.x - End1.scale * 42, this.y + End1.scale * 18, End1.scale * 6, End1.scale * 6);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x - End1.scale * 40, this.y + End1.scale * 23);
            End1.crc2.lineTo(this.x - End1.scale * 50, this.y + End1.scale * 26);
            End1.crc2.lineTo(this.x - End1.scale * 40, this.y + End1.scale * 18);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Bein 1 rechts
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 2, this.y + End1.scale * 2, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x + End1.scale * 3, this.y + End1.scale * 3, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillRect(this.x + End1.scale * 8, this.y + End1.scale * 4, End1.scale * 6, End1.scale * 6);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x + End1.scale * 12, this.y + End1.scale * 9); //untere
            End1.crc2.lineTo(this.x + End1.scale * 22, this.y + End1.scale * 12); //linke spitze
            End1.crc2.lineTo(this.x + End1.scale * 12, this.y + End1.scale * 4);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Bein 2 rechts
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 2, this.y + End1.scale * 9, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x + End1.scale * 3, this.y + End1.scale * 10, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillRect(this.x + End1.scale * 8, this.y + End1.scale * 11, End1.scale * 6, End1.scale * 6);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x + End1.scale * 12, this.y + End1.scale * 16);
            End1.crc2.lineTo(this.x + End1.scale * 22, this.y + End1.scale * 19);
            End1.crc2.lineTo(this.x + End1.scale * 12, this.y + End1.scale * 11);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Bein 3 rechts
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 2, this.y + End1.scale * 16, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x + End1.scale * 3, this.y + End1.scale * 17, End1.scale * 8, End1.scale * 6);
            End1.crc2.fillRect(this.x + End1.scale * 8, this.y + End1.scale * 18, End1.scale * 6, End1.scale * 6);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x + End1.scale * 12, this.y + End1.scale * 23);
            End1.crc2.lineTo(this.x + End1.scale * 22, this.y + End1.scale * 26);
            End1.crc2.lineTo(this.x + End1.scale * 12, this.y + End1.scale * 18);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Schere 1 links
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 30, this.y + End1.scale * 24, End1.scale * 6, End1.scale * 6);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x - End1.scale * 27, this.y + End1.scale * 33); //untere
            End1.crc2.lineTo(this.x - End1.scale * 37, this.y + End1.scale * 36); //spitze
            End1.crc2.lineTo(this.x - End1.scale * 27, this.y + End1.scale * 28);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x - End1.scale * 27, this.y + End1.scale * 33);
            End1.crc2.lineTo(this.x - End1.scale * 17, this.y + End1.scale * 36);
            End1.crc2.lineTo(this.x - End1.scale * 27, this.y + End1.scale * 28);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Schere 2 rechts
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fillRect(this.x - End1.scale * 8, this.y + End1.scale * 24, End1.scale * 6, End1.scale * 6);
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x - End1.scale * 4, this.y + End1.scale * 33); //untere
            End1.crc2.lineTo(this.x - End1.scale * 14, this.y + End1.scale * 36); //spitze
            End1.crc2.lineTo(this.x - End1.scale * 4, this.y + End1.scale * 28);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            End1.crc2.beginPath();
            End1.crc2.moveTo(this.x - End1.scale * 4, this.y + End1.scale * 33);
            End1.crc2.lineTo(this.x + End1.scale * 6, this.y + End1.scale * 36);
            End1.crc2.lineTo(this.x - End1.scale * 4, this.y + End1.scale * 28);
            End1.crc2.fillStyle = "#DB2929";
            End1.crc2.fill();
            //Krabbenaugen
            End1.crc2.beginPath();
            End1.crc2.arc(this.x - End1.scale * 22, this.y + End1.scale * 24, 2.5 * End1.scale, 0, End1.scale * 2 * Math.PI);
            End1.crc2.fillStyle = "black";
            End1.crc2.fill();
            End1.crc2.beginPath();
            End1.crc2.arc(this.x - End1.scale * 23, this.y + End1.scale * 24, End1.scale, 0, End1.scale * 2 * Math.PI);
            End1.crc2.fillStyle = "white";
            End1.crc2.fill();
            End1.crc2.beginPath();
            End1.crc2.arc(this.x - End1.scale * 10, this.y + End1.scale * 24, End1.scale * 2.5, 0, End1.scale * 2 * Math.PI);
            End1.crc2.fillStyle = "black";
            End1.crc2.fill();
            End1.crc2.beginPath();
            End1.crc2.arc(this.x - End1.scale * 11, this.y + End1.scale * 24, End1.scale, 0, End1.scale * 2 * Math.PI);
            End1.crc2.fillStyle = "white";
            End1.crc2.fill();
            /*HITZONES
            crc2.beginPath();
            crc2.moveTo(this.x+15, this.y);
            crc2.lineTo(this.x-45,this.y);
            crc2.fillStyle = "blue";
            crc2.stroke();
            */
        }
    }
    End1.Krabbe = Krabbe;
})(End1 || (End1 = {}));
//# sourceMappingURL=Krabbe.js.map